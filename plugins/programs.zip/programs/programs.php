<?php
/**
 * Plugin Name: Programs 
 * Description: Programs Custom Post Type Plugin
 * Version: 0.1
 * Author: Anariel Design
 * Author URI: http://www.anarieldesign.com
 */
add_action( 'init', 'anariel_childrenprograms_post_types'); 
function anariel_childrenprograms_post_types(){
	$labels=array(
		'name' => __( 'Programs', 'anariel' ),
		'singular_name' => __( 'Programs', 'anariel' )
	);

	$args=array(
		'labels' => $labels,
		'label' => __('Programs', 'anariel'),
		'singular_label' => __('Programs', 'anariel'),
		'public' => true,
		'show_ui' => true, 
		'_builtin' => false, 
		'capability_type' => 'post',
		'hierarchical' => false,
		'rewrite' => array('slug' => 'programs'), 
		'supports' => array('title','editor','excerpt','revisions','thumbnail','comments'),
		'taxonomies' => array('childrenprograms_cat', 'post_tag'),
		'menu_icon' => get_template_directory_uri('template_directory').'/images/programsicon.png'
	);

	if(function_exists('register_post_type')):
		register_post_type('childrenprograms', $args);
	endif;
}



//Custom Post Type columns
add_filter("manage_edit-childrenprograms_columns", "anariel_childrenprograms_columns");
add_action("manage_posts_custom_column",  "anariel_childrenprograms_custom_columns");
function anariel_childrenprograms_columns($columns){
		$columns = array(
			"cb" => "<input type=\"checkbox\" />",
			"title" => _x("Programs Title", "Programs title column", 'anariel'),
			"author" => _x("Author", "Programs author column", 'anariel'),
			"childrenprograms_cats" => _x("Programs Categories", "Programs categories column", 'anariel'),
			"date" => _x("Date", "Programs date column", 'anariel')
		);

		return $columns;
}

function anariel_childrenprograms_custom_columns($column){
		global $post;
		switch ($column)
		{
			case "author":
				the_author();
				break;
			case "childrenprograms_cats":
				echo get_the_term_list( $post->ID, 'childrenprograms_cat', '', ', ', '' ); 
				break;
		}
}



//Custom taxonomies
add_action('init', 'anariel_childrenprograms_taxonomies', 0);

function anariel_childrenprograms_taxonomies(){

	$labels = array(
		'name' => _x( 'Programs Categories', 'taxonomy general name', 'anariel' ),
		'singular_name' => _x( 'Programs Category', 'taxonomy singular name', 'anariel' ),
		'search_items' =>  __( 'Search Programs', 'anariel' ),
		'all_items' => __( 'All Programs Categories', 'anariel' ),
		'parent_item' => __( 'Parent Programs Category', 'anariel' ),
		'parent_item_colon' => __( 'Parent Programs Category:', 'anariel' ),
		'edit_item' => __( 'Edit Programs Category', 'anariel' ), 
		'update_item' => __( 'Update Programs Category', 'anariel' ),
		'add_new_item' => __( 'Add New Programs Category', 'anariel' ),
		'new_item_name' => __( 'New Programs Category Name', 'anariel' )
	); 	
	
	register_taxonomy('childrenprograms_cat',array('childrenprograms'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'childrenprograms_categories' )

	));
	
	 // Initialize New Taxonomy Labels
	  $labels = array(
		'name' => _x( 'Programs Tags', 'taxonomy general name','anariel' ),
		'singular_name' => _x( 'Programs Tag', 'taxonomy singular name','anariel' ),
		'search_items' =>  __( 'Search Types','anariel' ),
		'all_items' => __( 'All Tags','anariel' ),
		'parent_item' => __( 'Parent Tag','anariel' ),
		'parent_item_colon' => __( 'Parent Tag:','anariel' ),
		'edit_item' => __( 'Edit Tags','anariel' ),
		'update_item' => __( 'Update Tag','anariel' ),
		'add_new_item' => __( 'Add New Tag','anariel' ),
		'new_item_name' => __( 'New Tag Name','anariel' ),
	  );
		// Custom taxonomy for Project Tags
		register_taxonomy('childrenprograms_tag',array('project'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'childrenprograms_tag' ),
	  ));
	  
	  	add_action('admin_init','childrenprograms_meta_init');

	function childrenprograms_meta_init()
	{
		// add a meta box for WordPress 'project' type
		add_meta_box('childrenprograms_meta', 'Project Infos', 'childrenprograms_meta_setup', 'project', 'side', 'low');

		// add a callback function to save any data a user enters in
		add_action('save_post','childrenprograms_meta_save');
	}

	function childrenprograms_meta_setup()
	{
		global $post;

		?>
			<div class="childrenprograms_meta_control">
				<label>URL</label>
				<p>
					<input type="text" name="_url" value="<?php echo get_post_meta($post->ID,'_url',TRUE); ?>" style="width: 100%;" />
				</p>
			</div>
		<?php

		// create for validation
		echo '<input type="hidden" name="meta_noncename" value="' . wp_create_nonce(__FILE__) . '" />';
	}

	function childrenprograms_meta_save($post_id)
	{
		// check nonce
		if (!isset($_POST['meta_noncename']) || !wp_verify_nonce($_POST['meta_noncename'], __FILE__)) {
		return $post_id;
		}

		// check capabilities
		if ('post' == $_POST['post_type']) {
		if (!current_user_can('edit_post', $post_id)) {
		return $post_id;
		}
		} elseif (!current_user_can('edit_page', $post_id)) {
		return $post_id;
		}

		// exit on autosave
		if (defined('DOING_AUTOSAVE') == DOING_AUTOSAVE) {
		return $post_id;
		}

		if(isset($_POST['_url']))
		{
			update_post_meta($post_id, '_url', $_POST['_url']);
		} else
		{
			delete_post_meta($post_id, '_url');
		}
	}
}