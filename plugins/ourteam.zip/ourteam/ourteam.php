<?php
/**
 * Plugin Name: Team Members 
 * Description: Team Members Custom Post Type Plugin
 * Version: 0.1
 * Author: Anariel Design
 * Author URI: http://www.anarieldesign.com
 */
add_action( 'init', 'anariel_ourteam_post_types'); 
function anariel_ourteam_post_types(){
	$labels=array(
		'name' => __( 'Our Team', 'anariel' ),
		'singular_name' => __( 'Our Team', 'anariel' )
	);

	$args=array(
		'labels' => $labels,
		'label' => __('Our Team', 'anariel'),
		'singular_label' => __('Our Team', 'anariel'),
		'public' => true,
		'show_ui' => true, 
		'_builtin' => false, 
		'capability_type' => 'post',
		'hierarchical' => false,
		'rewrite' => array('slug' => 'ourteam'), 
		'supports' => array('title','editor','excerpt','revisions','thumbnail','comments'),
		'taxonomies' => array('ourteam_cat', 'post_tag'),
		'menu_icon' => get_template_directory_uri('template_directory').'/images/ourteamicon.png'
	);

	if(function_exists('register_post_type')):
		register_post_type('ourteam', $args);
	endif;
}



//Custom Post Type columns
add_filter("manage_edit-ourteam_columns", "anariel_ourteam_columns");
add_action("manage_posts_custom_column",  "anariel_ourteam_custom_columns");
function anariel_ourteam_columns($columns){
		$columns = array(
			"cb" => "<input type=\"checkbox\" />",
			"title" => _x("Our Team Title", "Our Team title column", 'anariel'),
			"author" => _x("Author", "Our Team author column", 'anariel'),
			"ourteam_cats" => _x("Our Team Categories", "Our Team categories column", 'anariel'),
			"date" => _x("Date", "Our Team date column", 'anariel')
		);

		return $columns;
}

function anariel_ourteam_custom_columns($column){
		global $post;
		switch ($column)
		{
			case "author":
				the_author();
				break;
			case "ourteam_cats":
				echo get_the_term_list( $post->ID, 'ourteam_cat', '', ', ', '' ); 
				break;
		}
}



//Custom taxonomies
add_action('init', 'anariel_ourteam_taxonomies', 0);

function anariel_ourteam_taxonomies(){

	$labels = array(
		'name' => _x( 'Our Team Categories', 'taxonomy general name', 'anariel' ),
		'singular_name' => _x( 'Our Team Category', 'taxonomy singular name', 'anariel' ),
		'search_items' =>  __( 'Search Our Team', 'anariel' ),
		'all_items' => __( 'All Our Team Categories', 'anariel' ),
		'parent_item' => __( 'Parent Our Team Category', 'anariel' ),
		'parent_item_colon' => __( 'Parent Our Team Category:', 'anariel' ),
		'edit_item' => __( 'Edit Our Team Category', 'anariel' ), 
		'update_item' => __( 'Update Our Team Category', 'anariel' ),
		'add_new_item' => __( 'Add New Our Team Category', 'anariel' ),
		'new_item_name' => __( 'New Our Team Category Name', 'anariel' )
	); 	
	
	register_taxonomy('ourteam_cat',array('ourteam'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'ourteam_categories' )

	));
	
	 // Initialize New Taxonomy Labels
	  $labels = array(
		'name' => _x( 'Our Team Tags', 'taxonomy general name','anariel' ),
		'singular_name' => _x( 'Our Team Tag', 'taxonomy singular name','anariel' ),
		'search_items' =>  __( 'Search Types','anariel' ),
		'all_items' => __( 'All Tags','anariel' ),
		'parent_item' => __( 'Parent Tag','anariel' ),
		'parent_item_colon' => __( 'Parent Tag:','anariel' ),
		'edit_item' => __( 'Edit Tags','anariel' ),
		'update_item' => __( 'Update Tag','anariel' ),
		'add_new_item' => __( 'Add New Tag','anariel' ),
		'new_item_name' => __( 'New Tag Name','anariel' ),
	  );
		// Custom taxonomy for Project Tags
		register_taxonomy('ourteam_tag',array('project'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'ourteam_tag' ),
	  ));
	  
	  	add_action('admin_init','ourteam_meta_init');

	function ourteam_meta_init()
	{
		// add a meta box for WordPress 'project' type
		add_meta_box('ourteam_meta', 'Project Infos', 'ourteam_meta_setup', 'project', 'side', 'low');

		// add a callback function to save any data a user enters in
		add_action('save_post','ourteam_meta_save');
	}

	function ourteam_meta_setup()
	{
		global $post;

		?>
			<div class="ourteam_meta_control">
				<label>URL</label>
				<p>
					<input type="text" name="_url" value="<?php echo get_post_meta($post->ID,'_url',TRUE); ?>" style="width: 100%;" />
				</p>
			</div>
		<?php

		// create for validation
		echo '<input type="hidden" name="meta_noncename" value="' . wp_create_nonce(__FILE__) . '" />';
	}

	function ourteam_meta_save($post_id)
	{
		// check nonce
		if (!isset($_POST['meta_noncename']) || !wp_verify_nonce($_POST['meta_noncename'], __FILE__)) {
		return $post_id;
		}

		// check capabilities
		if ('post' == $_POST['post_type']) {
		if (!current_user_can('edit_post', $post_id)) {
		return $post_id;
		}
		} elseif (!current_user_can('edit_page', $post_id)) {
		return $post_id;
		}

		// exit on autosave
		if (defined('DOING_AUTOSAVE') == DOING_AUTOSAVE) {
		return $post_id;
		}

		if(isset($_POST['_url']))
		{
			update_post_meta($post_id, '_url', $_POST['_url']);
		} else
		{
			delete_post_meta($post_id, '_url');
		}
	}
}