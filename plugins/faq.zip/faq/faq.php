<?php
/**
 * Plugin Name: FAQ 
 * Description: FAQ Custom Post Type Plugin
 * Version: 0.1
 * Author: Anariel Design
 * Author URI: http://www.anarieldesign.com
 */
add_action( 'init', 'anariel_faq_post_types'); 
function anariel_faq_post_types(){
	$labels=array(
		'name' => __( 'Faq', 'anariel' ),
		'singular_name' => __( 'Faq', 'anariel' )
	);

	$args=array(
		'labels' => $labels,
		'label' => __('Faq', 'anariel'),
		'singular_label' => __('Faq', 'anariel'),
		'public' => true,
		'show_ui' => true, 
		'_builtin' => false, 
		'capability_type' => 'post',
		'hierarchical' => false,
		'rewrite' => false, 
		'supports' => array('title','editor','excerpt','revisions','thumbnail','comments'),
		'taxonomies' => array('faq_cat', 'post_tag'),
		'menu_icon' => get_template_directory_uri('template_directory').'/images/faqicon.png'
	);

	if(function_exists('register_post_type')):
		register_post_type('faq', $args);
	endif;
}



//Custom Post Type columns
add_filter("manage_edit-faq_columns", "anariel_faq_columns");
add_action("manage_posts_custom_column",  "anariel_faq_custom_columns");
function anariel_faq_columns($columns){
		$columns = array(
			"cb" => "<input type=\"checkbox\" />",
			"title" => _x("Faq Title", "Faq title column", 'anariel'),
			"author" => _x("Author", "Faq author column", 'anariel'),
			"faq_cats" => _x("Faq Categories", "Faq categories column", 'anariel'),
			"date" => _x("Date", "Faq date column", 'anariel')
		);

		return $columns;
}

function anariel_faq_custom_columns($column){
		global $post;
		switch ($column)
		{
			case "author":
				the_author();
				break;
			case "faq_cats":
				echo get_the_term_list( $post->ID, 'faq_cat', '', ', ', '' ); 
				break;
		}
}



//Custom taxonomies
add_action('init', 'anariel_faq_taxonomies', 0);

function anariel_faq_taxonomies(){

	$labels = array(
		'name' => _x( 'Faq Categories', 'taxonomy general name', 'anariel' ),
		'singular_name' => _x( 'Faq Category', 'taxonomy singular name', 'anariel' ),
		'search_items' =>  __( 'Search Faq', 'anariel' ),
		'all_items' => __( 'All Faq Categories', 'anariel' ),
		'parent_item' => __( 'Parent Faq Category', 'anariel' ),
		'parent_item_colon' => __( 'Parent Faq Category:', 'anariel' ),
		'edit_item' => __( 'Edit Faq Category', 'anariel' ), 
		'update_item' => __( 'Update Faq Category', 'anariel' ),
		'add_new_item' => __( 'Add New Faq Category', 'anariel' ),
		'new_item_name' => __( 'New Faq Category Name', 'anariel' )
	); 	
	
	register_taxonomy('faq_cat',array('faq'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'faq_categories' )

	));
	
	 // Initialize New Taxonomy Labels
	  $labels = array(
		'name' => _x( 'Faq Tags', 'taxonomy general name','anariel' ),
		'singular_name' => _x( 'Faq Tag', 'taxonomy singular name','anariel' ),
		'search_items' =>  __( 'Search Types','anariel' ),
		'all_items' => __( 'All Tags','anariel' ),
		'parent_item' => __( 'Parent Tag','anariel' ),
		'parent_item_colon' => __( 'Parent Tag:','anariel' ),
		'edit_item' => __( 'Edit Tags','anariel' ),
		'update_item' => __( 'Update Tag','anariel' ),
		'add_new_item' => __( 'Add New Tag','anariel' ),
		'new_item_name' => __( 'New Tag Name','anariel' ),
	  );
		// Custom taxonomy for Project Tags
		register_taxonomy('faq_tag',array('project'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'faq_tag' ),
	  ));
	  
	  	add_action('admin_init','faq_meta_init');

	function faq_meta_init()
	{
		// add a meta box for WordPress 'project' type
		add_meta_box('faq_meta', 'Project Infos', 'faq_meta_setup', 'project', 'side', 'low');

		// add a callback function to save any data a user enters in
		add_action('save_post','faq_meta_save');
	}

	function faq_meta_setup()
	{
		global $post;

		?>
			<div class="faq_meta_control">
				<label>URL</label>
				<p>
					<input type="text" name="_url" value="<?php echo get_post_meta($post->ID,'_url',TRUE); ?>" style="width: 100%;" />
				</p>
			</div>
		<?php

		// create for validation
		echo '<input type="hidden" name="meta_noncename" value="' . wp_create_nonce(__FILE__) . '" />';
	}

	function faq_meta_save($post_id)
	{
		// check nonce
		if (!isset($_POST['meta_noncename']) || !wp_verify_nonce($_POST['meta_noncename'], __FILE__)) {
		return $post_id;
		}

		// check capabilities
		if ('post' == $_POST['post_type']) {
		if (!current_user_can('edit_post', $post_id)) {
		return $post_id;
		}
		} elseif (!current_user_can('edit_page', $post_id)) {
		return $post_id;
		}

		// exit on autosave
		if (defined('DOING_AUTOSAVE') == DOING_AUTOSAVE) {
		return $post_id;
		}

		if(isset($_POST['_url']))
		{
			update_post_meta($post_id, '_url', $_POST['_url']);
		} else
		{
			delete_post_meta($post_id, '_url');
		}
	}
}
?>
