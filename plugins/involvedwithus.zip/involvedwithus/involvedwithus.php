<?php
/**
 * Plugin Name: Get Involved
 * Description: Get Involved Post Type Plugin
 * Version: 0.1
 * Author: Anariel Design
 * Author URI: http://www.anarieldesign.com
 */
add_action( 'init', 'anariel_involvedwithus_post_types'); 
function anariel_involvedwithus_post_types(){
	$labels=array(
		'name' => __( 'Get Involved', 'anariel' ),
		'singular_name' => __( 'Get Involved', 'anariel' )
	);

	$args=array(
		'labels' => $labels,
		'label' => __('Get Involved', 'anariel'),
		'singular_label' => __('Get Involved', 'anariel'),
		'public' => true,
		'show_ui' => true, 
		'_builtin' => false, 
		'capability_type' => 'post',
		'hierarchical' => false,
		'rewrite' => array('slug' => 'involvedwithus'), 
		'supports' => array('title','editor','excerpt','revisions','thumbnail','comments'),
		'taxonomies' => array('involvedwithus_cat', 'post_tag'),
		'menu_icon' => get_template_directory_uri('template_directory').'/images/getinvolvedicon.png'
	);

	if(function_exists('register_post_type')):
		register_post_type('involvedwithus', $args);
	endif;
}



//Custom Post Type columns
add_filter("manage_edit-involvedwithus_columns", "anariel_involvedwithus_columns");
add_action("manage_posts_custom_column",  "anariel_involvedwithus_custom_columns");
function anariel_involvedwithus_columns($columns){
		$columns = array(
			"cb" => "<input type=\"checkbox\" />",
			"title" => _x("Get Involved Title", "Get Involved title column", 'anariel'),
			"author" => _x("Author", "Get Involved author column", 'anariel'),
			"involvedwithus_cats" => _x("Get Involved Categories", "Get Involved categories column", 'anariel'),
			"date" => _x("Date", "Get Involved date column", 'anariel')
		);

		return $columns;
}

function anariel_involvedwithus_custom_columns($column){
		global $post;
		switch ($column)
		{
			case "author":
				the_author();
				break;
			case "involvedwithus_cats":
				echo get_the_term_list( $post->ID, 'involvedwithus_cat', '', ', ', '' ); 
				break;
		}
}



//Custom taxonomies
add_action('init', 'anariel_involvedwithus_taxonomies', 0);

function anariel_involvedwithus_taxonomies(){

	$labels = array(
		'name' => _x( 'Get Involved Categories', 'taxonomy general name', 'anariel' ),
		'singular_name' => _x( 'Get Involved Category', 'taxonomy singular name', 'anariel' ),
		'search_items' =>  __( 'Search Get Involved', 'anariel' ),
		'all_items' => __( 'All Get Involved Categories', 'anariel' ),
		'parent_item' => __( 'Parent Get Involved Category', 'anariel' ),
		'parent_item_colon' => __( 'Parent Get Involved Category:', 'anariel' ),
		'edit_item' => __( 'Edit Get Involved Category', 'anariel' ), 
		'update_item' => __( 'Update Get Involved Category', 'anariel' ),
		'add_new_item' => __( 'Add New Get Involved Category', 'anariel' ),
		'new_item_name' => __( 'New Get Involved Category Name', 'anariel' )
	); 	
	
	register_taxonomy('involvedwithus_cat',array('involvedwithus'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'involvedwithus_categories' )

	));
	
	 // Initialize New Taxonomy Labels
	  $labels = array(
		'name' => _x( 'Get Involved Tags', 'taxonomy general name','anariel' ),
		'singular_name' => _x( 'Get Involved Tag', 'taxonomy singular name','anariel' ),
		'search_items' =>  __( 'Search Types','anariel' ),
		'all_items' => __( 'All Tags','anariel' ),
		'parent_item' => __( 'Parent Tag','anariel' ),
		'parent_item_colon' => __( 'Parent Tag:','anariel' ),
		'edit_item' => __( 'Edit Tags','anariel' ),
		'update_item' => __( 'Update Tag','anariel' ),
		'add_new_item' => __( 'Add New Tag','anariel' ),
		'new_item_name' => __( 'New Tag Name','anariel' ),
	  );
		// Custom taxonomy for Project Tags
		register_taxonomy('involvedwithus_tag',array('project'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'involvedwithus_tag' ),
	  ));
	  
	  	add_action('admin_init','involvedwithus_meta_init');

	function involvedwithus_meta_init()
	{
		// add a meta box for WordPress 'project' type
		add_meta_box('involvedwithus_meta', 'Project Infos', 'involvedwithus_meta_setup', 'project', 'side', 'low');

		// add a callback function to save any data a user enters in
		add_action('save_post','involvedwithus_meta_save');
	}

	function involvedwithus_meta_setup()
	{
		global $post;

		?>
			<div class="involvedwithus_meta_control">
				<label>URL</label>
				<p>
					<input type="text" name="_url" value="<?php echo get_post_meta($post->ID,'_url',TRUE); ?>" style="width: 100%;" />
				</p>
			</div>
		<?php

		// create for validation
		echo '<input type="hidden" name="meta_noncename" value="' . wp_create_nonce(__FILE__) . '" />';
	}

	function involvedwithus_meta_save($post_id)
	{
		// check nonce
		if (!isset($_POST['meta_noncename']) || !wp_verify_nonce($_POST['meta_noncename'], __FILE__)) {
		return $post_id;
		}

		// check capabilities
		if ('post' == $_POST['post_type']) {
		if (!current_user_can('edit_post', $post_id)) {
		return $post_id;
		}
		} elseif (!current_user_can('edit_page', $post_id)) {
		return $post_id;
		}

		// exit on autosave
		if (defined('DOING_AUTOSAVE') == DOING_AUTOSAVE) {
		return $post_id;
		}

		if(isset($_POST['_url']))
		{
			update_post_meta($post_id, '_url', $_POST['_url']);
		} else
		{
			delete_post_meta($post_id, '_url');
		}
	}
}